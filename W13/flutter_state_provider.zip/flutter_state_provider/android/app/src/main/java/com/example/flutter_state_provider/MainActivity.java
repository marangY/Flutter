package com.example.flutter_state_provider;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
