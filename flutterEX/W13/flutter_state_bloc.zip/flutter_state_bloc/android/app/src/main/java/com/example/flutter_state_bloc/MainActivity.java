package com.example.flutter_state_bloc;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
