package com.example.flutter_gesture_basic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
